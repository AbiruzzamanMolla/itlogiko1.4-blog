Date: 09-10-2019

# TODO:
- Design Post CRUD Pages
- Make Post CRUD
- 

Data: 13-10-2019
- Add Comment in Post page
- Add Registation Form and Serverside operations
- Add Registation Session
- Logout Session Distroy
- Add Login Form and Serverside operations
- Login Session and Show name in navbar

Date: 14-10-2019
- Adding Post in frontend
- Adding Category in Frontend
- Adding Pagination
- Adding Category wish post
- Adding Comment

Date: 15-10-2019
- Pagination in index page -X
- View post in category -X
- User Profile view -X
- User Profile Edit  - X(16-10)

Date: 16-10-2019
- Comment from post page

Date: 19-10-2019
- Refector edit user -X
- edit comment 
- report generate