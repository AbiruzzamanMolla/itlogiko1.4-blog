document.getElementById("footerYear").innerHTML = new Date().getFullYear();
// dismiss message after 6 second
$('#showMsg').delay(6000).fadeOut(300);