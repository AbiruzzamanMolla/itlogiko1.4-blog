<!-- Sidebar -->
<ul class="sidebar navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="allPost.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>All Posts</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="allCategory.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>All Category</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="allComment.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>All Comment</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="allUser.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>All Users</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="reportGen.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Report Genarate</span></a>
    </li>
</ul>